﻿using System;
namespace LAB_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int A, B, C;
            do
            {
                Console.WriteLine("Введiть значення A: ");
                A = int.Parse(Console.ReadLine());
            } while (A == 0);

            Console.WriteLine("Введiть значення B: ");
            B = int.Parse(Console.ReadLine());

            Console.WriteLine("Введiть значення C: ");
            C = int.Parse(Console.ReadLine());

            Console.WriteLine($"Квадратне рiвняння {A}x^2+{B}x+{C}=0 має дiйснi коренi: ");

            double D;
            D = Math.Pow(B, 2) - (4 * A * C);
            if (D >= 0)
            {
                Console.WriteLine(true);
            }
            else
            {
                Console.WriteLine(false);
            }
        }
    }
}