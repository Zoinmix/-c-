﻿using System;
namespace LAB_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double U;
            Console.WriteLine("Введiть значення напруги: ");
            U=double.Parse(Console.ReadLine());

            double I;
            Console.WriteLine("Введiть значення сили струму: ");
            I = double.Parse(Console.ReadLine());

            double R;
            R = U / I;
            Console.WriteLine($"Значення опору дорiвнює {R} Ом");
        }
    }
}