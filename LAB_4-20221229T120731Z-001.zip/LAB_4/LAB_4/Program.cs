﻿using System;

namespace LAB_4
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть розмiр масиву: ");
            int N;
            N=int.Parse(Console.ReadLine());
            
            int[] arr = new int[N];

            Console.WriteLine("Введiть елементи масиву: ");

            for (int i = 0; i < N; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Елементи з парних iндексiв: ");

            for (int j = 0; j < N; j++)
            {
                if (j % 2 == 0)
                {
                    Console.WriteLine(arr[j]);
                }
            }

            Console.WriteLine("Елементи з непарних iндексiв: ");

            for (int k = 0; k < N; k++)
            {
                if (k % 2 != 0)
                {
                    Console.WriteLine(arr[k]);
                }
            }

            Console.ReadLine();

        }
    }
}